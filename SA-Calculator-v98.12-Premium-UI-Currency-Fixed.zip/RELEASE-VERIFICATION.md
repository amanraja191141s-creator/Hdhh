## v1.98.6-v98.6 — Android service-worker bundle correction (2026-11-15)

- Reproduced packaging defect: the app registered `./service-worker.js`, but the Android web preparation script omitted it from `www/`.
- Corrected the staging script to require and copy `service-worker.js` beside `index.html`.
- Added an executable regression test which runs the real staging script and checks the generated worker and every worker precache dependency.
- Updated release/cache identity to v98.6; calculation/runtime algorithms and UI behavior were intentionally left unchanged.
- Verification: `npm test` — 150 passed, 0 failed; Android web bundle preparation passed. Physical Android WebView, APK installation and offline lifecycle still require device verification.

## v1.98.4-v98.4 — Currency converter deep audit release (2026-11-14)

- Re-audited currency picker, saved pair, swap, both amount inputs, reverse conversion, decimal precision, provider fallback, cache freshness, offline labeling, retry behavior and refresh metadata.
- Kept the already-tested currency runtime logic unchanged; no reproducible currency defect justified changing rate math or provider selection.
- Added `CURRENCY-CONVERTER-DEEP-AUDIT-v98.4.md` with scope, findings and verification limits.
- Updated release/cache identity to prevent older service-worker assets from masking this release.
- Full suite on the base source: 146 passed, 0 failed.

## v1.98.4-v98.4 — Settings and tools UI cleanup (2026-11-14)

- Removed the duplicate visible Accent Highlight Color selector. The 15-option accessible Accent Palette picker is now the single visible accent-selection control; the legacy accent field remains hidden for saved-preference migration and existing theme synchronization.
- Removed the disabled Diagnostics switch because this standalone build has no diagnostics upload feature and the control could not be enabled. The privacy disclosure and local-data clearing action remain.
- Removed the non-functional “Independent product” status row, decorative drawer hint, and the lone promotional Unit Price intro. All 17 calculator/converter destinations and their calculation controls remain available.
- Preserved fullscreen, font size, wake lock, appearance mode, OLED, angle unit, live preview, implicit multiplication, number formatting, language, startup screen, restore inputs, favorites, history, clipboard, sound, haptics, privacy/data clearing, help, feedback and reset controls.
- Updated app/package/manifest version and service-worker cache namespace.
- Added regression checks confirming the duplicate/inert controls are absent, the hidden saved-accent compatibility field remains, all 12 settings groups remain, and unique control IDs are preserved.

## v1.98.1-v98.1 — rounded 12-digit scientific threshold (2026-11-14)

- Reworked the calculator integer-digit threshold to count integer digits directly instead of relying on a floating-point logarithm or a raw magnitude comparison. Twelve integer digits remain ordinary; a 13th integer digit switches to scientific notation.
- The 12-significant-digit display rounding is now considered before choosing ordinary vs scientific display, preventing values that round across 1e12 from being rendered as an ordinary 13-digit integer. The underlying calculation value remains unchanged.
- Unified radical preview formatting with the same 12/13-digit boundary so a rounded root cannot bypass the shared scientific display rule.
- Added boundary regression coverage for positive/negative values, values just below/at/above 1e12, rounded-up boundary cases, six-place scientific mantissas, preview formatting, and radical results.
- Advanced app metadata and service-worker cache namespace to v98.1.

## v1.98.0-v98.0 — six-place scientific mantissa and 13-digit threshold (2026-11-14)

- Scientific mantissas now render as `n.nnnnnn×10^x` (up to six fractional digits, trailing zeros removed) across scientific entry, live preview, committed result, and scientific continuation.
- All 12-digit integer values remain in ordinary notation; scientific notation starts at `1×10^12`, when a 13th integer digit is present. Tiny non-zero values continue to use scientific notation to avoid disappearing in fixed-decimal display.
- Display formatting is presentation-only; the raw calculator value remains the operand for follow-on operations. Regression coverage includes values around `1e11`/`1e12`, mantissa rounding, small magnitudes, and continuation preview.

## v1.97.7-v97.7 — inclusive 12-digit scientific display and stable result continuation (2026-11-14)

- Calculator preview and committed result now switch to scientific notation at **12 integer digits** (inclusive, starting at `1e11`).
- The same formatter threshold is used for ordinary and radical calculation results; internal numeric precision remains unchanged.
- After `=`, pressing `+`, `−`, `×`, `÷`, or `^` preserves the visible scientific token (for example `1×10⁹`) in the continued expression while arithmetic uses the full raw numeric value.
- Added regression coverage for the 11/12-digit boundary and scientific-result continuation through all four arithmetic operators.

# Release verification — SA Calculator v1.94.0-v94

## Localization rebuild

- Reopened and inspected the actual v1.92.8 source ZIP before editing.
- 628 translation keys, each with seven non-English translations (4,396 values).
- 400 static HTML text/placeholder/accessibility inventory entries; zero unaccounted ordinary-language entries in the current inventory.
- 76 Unit Converter unit labels localized.
- 105 selectable currency names bundled for English, Hindi, Urdu, Spanish, French, German, Arabic and Chinese.
- Dynamic calculator, currency, date, history, loan, unit-price, settings and toast messages covered by translation templates.
- Locale-aware numbers and plural-sensitive date countdowns.
- RTL document direction for Arabic/Urdu; LTR calculator math and numeric entry.
- Service-worker cache includes the new currency-name data file.

## Verification

- Automated tests: **100/100 passed**.
- JavaScript syntax checks: passed.
- Static inventory and all-language catalogue checks: passed.
- Unit-label and currency-name coverage checks: passed.
- HTTP app-server smoke check: `200 OK`.
- ZIP integrity: checked at packaging.

## Outstanding manual gates

- Native-speaker review for all seven translations.
- Physical Android/Acode WebView testing, especially Arabic/Urdu layout and older WebView Intl fallback.
- Browser visual testing could not be completed in this environment because local navigation was blocked by the browser runtime.

This build is a materially improved localization development release, not a guarantee of zero bugs, zero lag, native-speaker certification, or complete physical-device compatibility.

## v1.94.0 basic calculator and app-controls regression pass

- Reopened the v1.92.9 source archive and inspected the parser, keypad insertion, result commit/repeat-equals flow, memory controls, history retention/restore, settings persistence and tool calculator test coverage.
- Fixed three calculator parser edge cases: malformed adjacent numeric tokens now reject; documented constant adjacency `pi2`/`2pi2`/`e2` now parses as multiplication; scientific exponent signs are excluded from repeat-equals operator detection.
- Memory recall now clears stale transient result/repeat/scientific-continuation state.
- The Settings Strong vibration option (`heavy`) now triggers 50 ms rather than falling through to the medium default.
- Unit conversion rejects temperatures below absolute zero in either Kelvin conversion direction; GPA uses credit-weighted points and ignores empty/zero-credit rows.
- Added 10 focused regression tests plus edge assertions for Kelvin absolute zero and loan amortization; full suite result: **100 passed, 0 failed, 0 skipped**.
- Browser visual smoke testing was attempted with headless Chromium, but this environment blocks local and file navigation at the browser policy layer. Automated Node tests and the local HTTP server checks remain available; physical Android/Acode testing is still required.


## v1.94.0-v94 screen design polish verification
- Added a final responsive visual layer for calculator, tool cards, forms, result cards, settings, history, drawers, dialogs and currency picker.
- Added compact-width, short-height and expanded-window layout rules, safe-area spacing, visible focus, reduced-motion and forced-colors support.
- Updated service-worker cache namespace to `sa-calculator-v94-1-94-0-screen-design-polish`.
- Test result: 102 passed, 0 failed, 0 skipped. CSS parsed with tinycss2: 2,379 top-level rules, 0 parse errors.
- Local HTTP smoke checks returned 200 for the app shell and core assets. Physical Android/Acode visual and touch QA remains outstanding.

## v1.97.1-v97.1 server and picker hardening

- Static server rejects decoded NUL paths with `400` and continues serving subsequent requests.
- `HEAD` now returns the correct representation `Content-Length` with an empty body.
- Encoded path traversal and hidden-file requests are blocked; unsupported methods return `405` and `Allow: GET, HEAD`.
- Server response headers are covered by integration tests.
- Dynamic select option picker clears `aria-activedescendant` before rebuilding options, avoiding stale references when the option set becomes empty.
- Automated tests: **108 passed, 0 failed, 0 skipped**.
- Physical Android/Acode testing, screen-reader behavior and visual layout at target viewport sizes remain outstanding; automated checks do not certify zero lag or zero defects on every device.


## v1.97.1-v97.1 video-driven scientific calculator correction

- Reviewed the supplied 14-Nov-2026 Android screen recording and reproduced the visible failure path from the source: scientific-function insertion explicitly set `calcScientificErrorPreview=true`, so valid root/function expressions were displayed as `Error` before the parser result could be shown.
- Removed the forced-error behavior for valid scientific-key edits. Incomplete expressions remain incomplete; mathematically invalid expressions still surface parser errors.
- Scientific functions tapped after a committed result now build an expression from the committed answer rather than the hidden source expression.
- Exact committed numeric value is now substituted when its scientific display token appears inside a wrapper such as `√(token)`; stale precision metadata is invalidated when the token is edited.
- Added six regression tests for scientific continuation, live radical preview, stale metadata invalidation, result-action expression construction, overflow boundaries and the absence of forced Error state.
- JavaScript syntax and full regression suite checked for this release.
- Range note: `9^99` is finite in JavaScript Number; `9^999` and `9^9999` exceed its finite range and correctly remain an explicit range error. Arbitrary-precision integer/exponent support is a separate engine feature, not silently claimed here.
- Physical Android/Acode playback and touch QA remain required; automated tests do not certify zero lag or universal device compatibility.

## v1.97.1-v97.1 — stable live-preview error geometry

- Recording-driven correction: live-preview `Error` previously activated legacy CSS that reduced the preview row to a 34px minimum and forced a smaller 16–23px label. This made the display visibly jump when an invalid expression appeared.
- The error state now retains the same preview row height, alignment, and layout as a normal preview. Only the semantic error color changes.
- The preview fitter now publishes its exact measured font size as `--calc-preview-fitted-size`; the Error label consumes that same value, so its text size exactly matches the normal preview at the current viewport and available width.
- Compact viewport fallback uses the same fitted-size variable; committed-result cleanup removes the transient variable.
- Added regression checks for row geometry, typography parity, and the shared measured font-size path.
- Automated tests: **118 passed, 0 failed, 0 skipped**.
- Physical Android/Acode visual verification remains required to confirm device-specific font metrics and touch behavior.

## v1.97.1-v97.1 — stable live-preview error geometry

- Recording-driven correction: live-preview `Error` previously activated legacy CSS that reduced the preview row to a 34px minimum and forced a smaller 16–23px label. This made the display visibly jump when an invalid expression appeared.
- The error state now retains the same preview row height, alignment, and layout as a normal preview. Only the semantic error color changes.
- The preview fitter now publishes its exact measured font size as `--calc-preview-fitted-size`; the Error label consumes that same value, so its text size exactly matches the normal preview at the current viewport and available width.
- Compact viewport fallback uses the same fitted-size variable; committed-result cleanup removes the transient variable.
- Added regression checks for row geometry, typography parity, and the shared measured font-size path.
- Automated tests: **118 passed, 0 failed, 0 skipped**.
- Physical Android/Acode visual verification remains required to confirm device-specific font metrics and touch behavior.

## v1.97.1-v97.1 server symlink boundary verification

- `node --check server.js`: passed.
- Targeted server security tests: **6 passed, 0 failed**.
- Full `npm test`: **119 passed, 0 failed, 0 skipped**.
- Symlink regression verifies an in-project symlink to an external temporary file is denied with HTTP 403 and does not disclose file contents.
- Android/Acode device replay remains unverified in this environment.



## v1.97.2-v97.2 — overflow-safe radical-of-power evaluation (2026-11-14)

A supplied Android screen recording showed `∛9^966` producing `Error` even though its final cube-root value (`9^322`) is within the finite IEEE-754 Number range. The parser previously evaluated `9^966` first, overflowed to Infinity, and rejected the expression before applying the cube root.

The leading radical parser now evaluates an unparenthesized power as `base^(exponent / degree)` for square/cube roots, preserving the finite-result case while continuing to reject genuinely out-of-range final results and invalid square-root domains. Regression coverage includes live preview, committed evaluation, negative cube-root sign, square-root domain rejection, and a still-overflowing cube-root case.

## v1.97.4-v97.4 — memory and parenthesized scientific-root integrity (2026-11-14)

- Added runtime regression coverage for MC/MR/MS/M+/M−, persistence, empty/corrupt storage, invalid inputs, and recall-state cleanup.
- Fixed parenthesized radical powers such as `∛(9^966)` and `√(9^324)` so a finite final root is evaluated without first overflowing the radicand.
- Added regression coverage for compact and parenthesized radical forms, overflow boundaries, and live preview.
- Bumped the app and service-worker cache version to prevent stale scripts from masking the fix.


## v1.97.4-v97.4 — error alignment and scientific E entry
- Live-preview and committed Error rows now retain the same 25px horizontal safe inset as the expression/preview/result rows.
- Bare scientific exponent entry `e2` is interpreted as `1e2` (100), and `e-2` as `1e-2` (0.01); mantissa notation (`2e2`) and Euler constant (`e`, `2e`, `e^2`) remain supported.
- Regression coverage added for boundary inset and scientific exponent entry.


## v1.97.5-v97.5 — exponent-marker semantics (2026-11-14)
- The scientific `e` key is an exponent-entry marker only; it is not Euler's constant.
- Bare `e`, `2e`, and `e^2` are invalid and display `Error` in live preview; equals does not commit a false numeric result.
- `e20` and `e+20` evaluate as `1e20`; `e-20` evaluates as `1e-20`; ordinary mantissa notation such as `2e20` remains supported.
- The same scientific-entry formatter is used for live preview and committed results, so `e20` remains `1 × 10²⁰` after equals.
- Added regression cases for exponent-only shorthand, invalid bare marker forms, and standard scientific mantissas.
- Automated regression suite: pending final run in this archive.


## v1.97.6-v97.6 — strict `e` marker and committed scientific display (2026-11-14)

- `e` is never Euler's constant in this calculator. A standalone `e`, `e^2`, or incomplete `2e` is invalid and must display `Error`.
- Exponent-only shorthand remains supported: `e2` = `1×10²`, `e20` = `1×10²⁰`, and `e-2` = `1×10⁻²`.
- The equals/committed-result path uses the same scientific-entry formatter as live preview, so `e20` remains `1×10²⁰` after equals rather than changing to an ordinary decimal or Euler value.
- Scientific notation is presentation-only; the raw numeric value remains the calculation source for subsequent operations.


## v1.97.9-v97.9 — recording-driven Error row geometry stability (2026-11-14)

- Inspected the 38.07-second Android screen recording and identified conflicting error-only preview heights (48–76px live, 30px committed) against the normal 32px preview lane.
- Unified normal/live-error/committed-error preview rows at a fixed 32px flex basis, height and min/max height, with centered alignment.
- Removed error-only line-height and letter-spacing overrides; only semantic error color and weight differ.
- Preserved the 25px horizontal display inset and updated the service-worker cache namespace.
- Added regression tests for row geometry, typography metrics, and horizontal inset. Device-specific Android WebView validation remains outstanding.


## v1.97.9-v97.9 — scientific continuation preview consistency (2026-11-14)
- Fixed a recording-reproduced mismatch where a committed scientific result such as `1×10⁹` remained scientific in the expression row after an operator was pressed, but the secondary live-preview row reverted to locale-grouped decimal (`1,00,00,00,000`).
- `formatCalculatorExpressionResult()` now recognizes a scientific display token anywhere in the active expression and uses the shared scientific display formatter for the preview/result value.
- Exact numeric evaluation and `STATE.calcRawValue` / `STATE.calcScientificContinuation` remain authoritative; only presentation formatting is kept consistent.
- Added regression coverage for `1×10⁹×` → `1×10⁹`, `1×10⁹×2` → `2×10⁹`, and `1×10⁹+2` → `1.000000002×10⁹`.


## v1.98.2-v98.2 — e12 threshold and scientific memory recall (2026-11-14)
- Verified exponent-entry boundary: `e11` and `2e11` remain ordinary 12-digit values; `e12` and `2e12` use scientific notation.
- Verified preview and equals use the same threshold and six-fractional-digit mantissa formatter.
- Verified MS → MR round-trip for scientific values: MR shows the six-place scientific display token while exact stored numeric value remains available to expression evaluation.
- Verified ordinary 12-digit memory recalls remain ordinary and scientific 13-digit memory recalls remain scientific.
