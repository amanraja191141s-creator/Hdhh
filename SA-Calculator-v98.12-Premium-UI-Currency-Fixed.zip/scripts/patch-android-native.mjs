import { cp, mkdir, readFile, readdir, writeFile, access } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const android = path.join(root, 'android');
const res = path.join(android, 'app', 'src', 'main', 'res');
await access(path.join(android, 'app', 'src', 'main', 'AndroidManifest.xml'));

// Replace generated Capacitor launcher icons with the same verified brand artwork.
const iconRoot = path.join(root, 'assets', 'brand', 'android-icons');
for (const dir of await readdir(iconRoot, { withFileTypes: true })) {
  if (!dir.isDirectory() || !/^mipmap-(?:mdpi|hdpi|xhdpi|xxhdpi|xxxhdpi)$/.test(dir.name)) continue;
  const targetDir = path.join(res, dir.name);
  await mkdir(targetDir, { recursive: true });
  for (const file of ['ic_launcher.png', 'ic_launcher_round.png']) {
    const source = path.join(iconRoot, dir.name, file);
    await access(source);
    await cp(source, path.join(targetDir, file));
  }
}
await mkdir(path.join(res, 'drawable'), { recursive: true });
await cp(path.join(iconRoot, 'drawable', 'ic_launcher_foreground.png'), path.join(res, 'drawable', 'ic_launcher_foreground.png'));
await mkdir(path.join(res, 'values'), { recursive: true });
await writeFile(path.join(res, 'values', 'ic_launcher_background.xml'), '<resources><color name="ic_launcher_background">#061A45</color></resources>\n');
await mkdir(path.join(res, 'mipmap-anydpi-v26'), { recursive: true });
const adaptive = `<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background" />\n    <foreground android:drawable="@drawable/ic_launcher_foreground" />\n</adaptive-icon>\n`;
await writeFile(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher.xml'), adaptive);
await writeFile(path.join(res, 'mipmap-anydpi-v26', 'ic_launcher_round.xml'), adaptive);

// Give Android's system bars a deliberate high-contrast surface and reserve
// the WebView's safe viewport for app content. Patch every generated values* theme file.
const valuesDirs = (await readdir(res, { withFileTypes: true }))
  .filter(entry => entry.isDirectory() && entry.name.startsWith('values'))
  .map(entry => path.join(res, entry.name));
let patched = 0;
for (const dir of valuesDirs) {
  for (const file of await readdir(dir)) {
    if (!file.endsWith('.xml')) continue;
    const full = path.join(dir, file);
    let xml = await readFile(full, 'utf8');
    if (!/<style\b[^>]*name="AppTheme(?:\.[^"]+)?"/.test(xml)) continue;
    xml = xml.replace(/(<style\b[^>]*name="AppTheme(?:\.[^"]+)?"[^>]*>)([\s\S]*?)(<\/style>)/g, (whole, open, body, close) => {
      const items = [
        ['android:windowDrawsSystemBarBackgrounds', 'true'],
        ['android:statusBarColor', '#07152E'],
        ['android:windowLightStatusBar', 'false'],
        ['android:navigationBarColor', '#07152E'],
        ['android:windowLightNavigationBar', 'false'],
        ['android:windowActionModeOverlay', 'true']
      ];
      let next = body;
      for (const [name, value] of items) {
        const tag = `<item name="${name}">${value}</item>`;
        const re = new RegExp(`<item\\s+name="${name.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}"[^>]*>[\\s\\S]*?<\\/item>`);
        if (re.test(next)) next = next.replace(re, tag);
        else next += `\n        ${tag}`;
      }
      return `${open}${next}\n    ${close}`;
    });
    await writeFile(full, xml);
    patched++;
  }
}
if (!patched) throw new Error('No AppTheme style found; cannot apply Android system-bar styling safely.');
console.log(`Android branding applied: launcher icons copied; ${patched} theme XML file(s) patched.`);
