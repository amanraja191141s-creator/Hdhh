# SA Calculator v1.97.1-v97.1 — Server and Picker Reliability Audit

## Scope
Reviewed the actual v1.94.0-v94 project source and extended the release with narrowly scoped fixes to the optional Node static server and the dynamically rendered native-select replacement.

## Findings and fixes

1. **Decoded NUL path could throw during filesystem access.** A URL path containing `%00` decoded to a string with a NUL byte. Node filesystem APIs reject such paths synchronously, which could terminate the server process. The server now rejects the decoded path with HTTP `400` before filesystem access.
2. **HEAD implementation discarded the response body by monkey-patching `res.end`.** The previous implementation read the full file and replaced the response method, while not reliably advertising the representation length. The server now uses a shared response helper with an explicit HEAD-only mode and `Content-Length`.
3. **Server could not be imported safely for isolated tests.** Server creation is now exposed through `createServer()` and listening occurs only when `server.js` is run as the entry point.
4. **Dynamic option picker could retain a dangling active-descendant reference.** If options were removed while a picker was open, the old `aria-activedescendant` could point to a removed node. It is now cleared before each active-option update.

## Regression coverage

- App shell returns `200` with security headers.
- HEAD returns the same representation length as GET and an empty body.
- Encoded NUL returns `400`; a follow-up request still succeeds.
- Encoded traversal is denied and hidden files are not exposed.
- Unsupported methods return `405` with `Allow: GET, HEAD`.
- Picker active-descendant cleanup is source-regression checked.

## Verification boundary

The automated suite verifies source-level behavior and HTTP server behavior. It does not substitute for real Android WebView interaction, Acode hosting, visual comparison, screen-reader testing, native-speaker review, or performance profiling on the target device. No claim of zero bugs or zero lag is made.

## v1.97.1-v97.1 server symlink boundary hardening (2026-11-14)

- Deep review found that the static server's lexical `path.resolve` / `path.relative` traversal check did not constrain filesystem symlinks. A symlink placed inside the served project tree could therefore point to a readable file outside the project root.
- The server now resolves each requested file with `fs.realpath` and validates the resolved target against the canonical application root before reading it.
- Added an HTTP regression test that creates a temporary external sentinel file and an in-project symlink, verifies the request is denied with HTTP 403, and removes both test artifacts.
- The fix does not change calculator behavior or cached front-end assets; the service-worker cache identifier is still advanced for release consistency.
- Automated suite after the patch: **119 passed, 0 failed, 0 skipped**.

